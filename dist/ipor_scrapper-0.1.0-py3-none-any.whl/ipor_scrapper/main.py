from scrapper_service import Scrapper
from loggers import configure_logging
from configuration.properties.config import ProductionConfig
from configuration.properties.config import TestingConfig
from tests import test_configuration

configure_logging()

# configuration = TestingConfig()
# config = test_configuration.import_configuration()
configuration = ProductionConfig()
# config = configuration.import_configuration()

scrapper_service = Scrapper(configuration)
scrapper_service.scrape_reserve_data()
