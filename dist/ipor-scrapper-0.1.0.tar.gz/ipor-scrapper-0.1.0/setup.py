# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ipor_scrapper',
 'ipor_scrapper.configuration',
 'ipor_scrapper.configuration.properties',
 'ipor_scrapper.ethereum',
 'ipor_scrapper.mathematics',
 'ipor_scrapper.tests',
 'ipor_scrapper.tests.test_configuration',
 'ipor_scrapper.tests.test_mathematics']

package_data = \
{'': ['*'],
 'ipor_scrapper': ['containers/kibana/*', 'external/aave_v1/*'],
 'ipor_scrapper.tests': ['.pytest_cache/*']}

install_requires = \
['PyYAML>=5.4.1,<6.0.0',
 'elasticsearch>=7.16.3,<8.0.0',
 'env>=0.1.0,<0.2.0',
 'logger>=1.4,<2.0',
 'loguru>=0.5.3,<0.6.0',
 'pathlib>=1.0.1,<2.0.0',
 'pyaml-env>=1.1.3,<2.0.0',
 'python-dotenv>=0.19.2,<0.20.0',
 'web3>=5.26.0,<6.0.0']

setup_kwargs = {
    'name': 'ipor-scrapper',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Adrian Skawinski',
    'author_email': 'adrian@ipor.io',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
