import json
from loguru import logger
import pathlib

from ethereum.connection_manager import ConnectionManager
from save_data import SaveData
from dtos import AssetContractDto

parent_path = pathlib.Path(__file__).parent.resolve()


class Scrapper:
    def __init__(self, _configuration):
        self.env_config = _configuration
        self.configuration = _configuration.import_configuration()
        self.connection_manager = ConnectionManager(_configuration)
        self.data_configuration_ethereum = self.configuration['io.ipor.scrapper']['ethereum']
        self.latest_block_number = self.connection_manager.get_web3().eth.get_block('latest').number
        self.start_block_number = self.get_start_block_number()

    def get_start_block_number(self):
        block_number = self.data_configuration_ethereum['start-block-number']
        return block_number

    def save_to_configuration(self, block_number, es_id):
        self.data_configuration_ethereum['start-block-number'] = block_number
        self.configuration['io.ipor.scrapper']['save-data']['elasticsearch']['id'] = es_id
        self.env_config.export_configuration(self.configuration)
        logger.info("Write to configuration file")

    def scrape_reserve_data(self) -> bool:
        block_number = self.start_block_number
        current_timestamp = 0
        output = SaveData()
        logger.info("Latest block number: {}", self.latest_block_number)
        es_id = self.configuration['io.ipor.scrapper']['save-data']['elasticsearch']['id']  # TODO: technical debt

        if block_number > self.latest_block_number:
            logger.error("Start block number is less then latest block number")
            return False

        else:

            while block_number <= self.latest_block_number:
                logger.info("current block number: {}", block_number)
                step = self.data_configuration_ethereum['read-block-number-step']
                for asset in self.data_configuration_ethereum['currencies']:
                    stable_coin_address = self.data_configuration_ethereum['currencies'][asset]['contract-address']
                    reserve_data = self.connection_manager.get_reserve_data(stable_coin_address, block_number)
                    dto = AssetContractDto(asset, reserve_data, block_number, self.env_config)

                    if current_timestamp < dto.lastUpdateTimestamp:
                        send_data = json.dumps(dto.__dict__)  # convert object to json object
                        es_id += 1
                        output.save_data(send_data, asset, es_id)

                current_timestamp = dto.lastUpdateTimestamp
                if block_number < self.latest_block_number:
                    block_number += step
                else:
                    block_number += 1

            self.save_to_configuration(block_number, es_id)
            return True
